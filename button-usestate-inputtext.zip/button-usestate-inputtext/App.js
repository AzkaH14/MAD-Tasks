import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

const MyButtonScreen = () => {
  const [buttonTitle, setButtonTitle] = useState('enter');
  const [inputText, setInputText] = useState('');

  const handlePress = () => {
    // Toggle button title between "Hello" and "Pressed"
    setButtonTitle(prevTitle => (prevTitle === 'enter' ? 'invalid' : 'enter'));
  };

  return (
    <View style={styles.container}>
      {/* Text Input */}
      <TextInput
        style={styles.input}
        placeholder="Enter some text"
        value={inputText}
        onChangeText={setInputText}
      />
      
      {/* Button */}
      <Button title={buttonTitle} onPress={handlePress} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  input: {
    height: 40,
    color:'gray',
    borderColor: 'lightgray',
    borderWidth: 1,
    marginBottom: 20,
    width: '100%',
    paddingLeft: 8,
  },
});

export default MyButtonScreen;
